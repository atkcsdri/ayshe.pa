// JavaScript (اضافه بر کد داخل HTML)

// افکت پراکنده شدن گل‌ها هنگام باز کردن نامه

document.querySelector('.envelope').addEventListener('click', function() {

    const flowers = document.querySelector('.flowers');

    flowers.innerHTML = '';

    

    for(let i = 0; i < 5; i++) {

        const flower = document.createElement('i');

        flower.className = 'fas fa-spa';

        flower.style.position = 'absolute';

        flower.style.left = Math.random() * 100 + '%';

        flower.style.top = Math.random() * 100 + '%';

        flower.style.fontSize = (Math.random() * 20 + 10) + 'px';

        flower.style.opacity = '0';

        flower.style.transform = 'scale(0)';

        flower.style.color = `hsl(${Math.random() * 30 + 330}, 100%, ${Math.random() * 20 + 70}%)`;

        flower.style.animation = `float ${Math.random() * 3 + 2}s ease-in-out forwards`;

        

        flowers.appendChild(flower);

        

        // انیمیشن گل‌ها

        setTimeout(() => {

            flower.style.opacity = '1';

            flower.style.transform = 'scale(1)';

        }, i * 100);

    }

});

// اضافه کردن استایل انیمیشن جدید

const style = document.createElement('style');

style.textContent = `

    @keyframes float {

        0% { transform: translateY(0) rotate(0deg) scale(0); opacity: 0; }

        50% { transform: translateY(-50px) rotate(180deg) scale(1); opacity: 1; }

        100% { transform: translateY(-100px) rotate(360deg) scale(0); opacity: 0; }

    }

`;

document.head.appendChild(style);